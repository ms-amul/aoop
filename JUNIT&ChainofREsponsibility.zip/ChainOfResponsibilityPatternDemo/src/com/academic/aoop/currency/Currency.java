package com.academic.aoop.currency;



/*Currency class will store the amount to dispense and used by the chain implementations. */

public class Currency {
	
	private int amount;
	
	//Initializes the amount variable
	public Currency(int amount) {
		super();
		this.amount = amount;
	}
	
	//To get the amount
	public int getAmount() {
		return amount;
	}
}
