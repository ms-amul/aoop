package com.academic.aoop.client;

import java.util.Scanner;

import com.academic.aoop.currency.Currency;
import com.academic.aoop.dispensechain.DispenseChain;
import com.academic.aoop.rupeedispenser.Rupee100Dispenser;
import com.academic.aoop.rupeedispenser.Rupee2000Dispenser;
import com.academic.aoop.rupeedispenser.Rupee200Dispenser;
import com.academic.aoop.rupeedispenser.Rupee500Dispenser;

public class Client {
	
	private DispenseChain chain1;
	
	

	public Client() {
		
		// initialize the chain
		chain1 = new  Rupee2000Dispenser();
		DispenseChain chain2 = new Rupee500Dispenser();
		DispenseChain chain3 = new Rupee200Dispenser();
		DispenseChain chain4 = new Rupee100Dispenser();
		
		chain1.setNextChain(chain2);
		chain2.setNextChain(chain3);
		chain3.setNextChain(chain4);
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client atmDispenser = new Client();
		while(true) {
			int amount = 0;
			Scanner sc = null;
			System.out.println("Enter amount to dispense");
			try {
				sc = new Scanner(System.in); 
				amount = sc.nextInt();
				if (amount % 100 != 0) {
					System.out.println("Amount should be in multiple of 100s.");
					return;
				}else {
					// process the request
					atmDispenser.chain1.dispense(new Currency(amount));
				}
				
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
	}
}
