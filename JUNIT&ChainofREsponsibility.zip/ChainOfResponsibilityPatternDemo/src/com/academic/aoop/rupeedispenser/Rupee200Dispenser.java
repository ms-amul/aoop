package com.academic.aoop.rupeedispenser;

import com.academic.aoop.currency.Currency;
import com.academic.aoop.dispensechain.DispenseChain;

public class Rupee200Dispenser implements DispenseChain {

	private DispenseChain chain;
	@Override
	public void setNextChain(DispenseChain nextChain) {
		// TODO Auto-generated method stub
		this.chain = nextChain;
		
	}

	@Override
	public void dispense(Currency currency) {
		// TODO Auto-generated method stub
		if(currency.getAmount() >= 200) {
			int numberOfNotes = currency.getAmount()/200;
			int remainder = currency.getAmount() % 200;
			System.out.println("Dispensing "+ numberOfNotes + " 200rupee note");
			if(remainder !=0 ) {
				chain.dispense(new Currency(remainder));
			}
		}else {
			chain.dispense(currency);
		}
		
	}


}
