
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.academic.aoop.junit.calculator.Calculator;

public class CalculatorTest {
	
	Calculator calculator = new Calculator();
	
	/*
	 * @Test
	 * 
	 * public void testString() { String s =
	 * calculator.concat("Earth Revolves"," Around Sun.");
	 * assertEquals("Earth Revolves Around Sun.",s); }
	 */
	/*
	 * @BeforeClass public static void testBeforeClassSample() { //Why static ?
	 * //this method is called only once. calculator = new Calculator();
	 * System.out.println("beforeclass annotation"); }
	 */
	
	
	
	@AfterClass
	public static void testSample() {
		System.out.println("after annotation");
	}
	@Test
	public void testAdd() {
		int result = calculator.add(12,142);
		
		assertEquals(154,result);
		System.out.println("Addition Operation");
	}
	@Test
	public void testSub() {
		int result = calculator.sub(123, 23);
		assertEquals(100, result);
		System.out.println("Subtraction operation");
	}
	@Test
	public void testDiv() {
		int result =(int) calculator.div(100, 10);
		assertEquals(10, result);
		System.out.println("Division Operation");
	}
	/*
	 * @AfterClass public static void testAfterClassSample() { //Why static ? //this
	 * method is called only once. calculator = null;
	 * System.out.println(calculator); }
	 */
	
	
}
