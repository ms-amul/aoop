package com.academic.aoop.junit.calculator;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest {
	
	static Calculator calculator;
	
	@BeforeClass
	public static void testBeforeClassSample() {		//Why static ? //this method is called only once.
		calculator = new Calculator();
		System.out.println("beforeclass annotation");
	}
	
	
	
	@Before
	public void testSample() {
		System.out.println("before annotation");
	}
	@Test
	public void testAdd() {
		//int result = new Calculator().add(12,142);
		
		assertEquals(154,calculator.add(12,142));
		System.out.println("Addition Operation");
	}
	@Test
	public void testSub() {
		int result = calculator.sub(123, 23);
		assertEquals(100, result);
		System.out.println("Subtraction operation");
	}
	@Test
	public void testDiv() {
		int result =(int) calculator.div(100, 10);
		assertEquals(10, result);
		System.out.println("Division Operation");
	}
	@AfterClass
	public static void testAfterClassSample() {		//Why static ? //this method is called only once.
		calculator = null;
		System.out.println(calculator);
	}
	
	
}
