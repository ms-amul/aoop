package com.academic.aoop.junit.calculator;

public class Calculator {
	
	public  int add(int a,int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	public int sub(int a,int b) {
		return a-b;
	}
	public double div(int a,int b) {
		double res = 0.0;
		if(b==0) {
			System.out.println("division can't be performed");
		}else {
			res = a/b;
		}
		return res;
	}
	public String concat(String a,String b) {
		return a+b;
	}
	
	

}
