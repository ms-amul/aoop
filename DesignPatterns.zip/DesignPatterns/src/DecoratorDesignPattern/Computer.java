package DecoratorDesignPattern;

public interface Computer {
	void assemble();   
}
