package SingletonLazyInitialization;

public class Singleton2 {
	private static Singleton2 instance;
	public Singleton2(){}
	
	public static  Singleton2 getinstance()
	{
		instance = new Singleton2();
		return instance;
	}
	
	public void show()
	{
		System.out.println("Hi there this is Lazy initialization in Singleton Design pattern");
	}
	
	public int sum(int a,int b,int c)
	{
		int d = a+b+c;
		return d;
	}
	
}
