package SingletonLazyInitialization;
import java.util.*;

public class Singleton2Demo extends Singleton2{

	public static void main(String[] args) {
		Singleton2 obj = Singleton2.getinstance();
		obj.show();
		
		int a,b,c;
		Scanner scan = new Scanner(System.in);
		a = scan.nextInt();
		b = scan.nextInt();
		c = scan.nextInt();
		scan.close();
		
		
		
		int x = obj.sum(a, b, c);
		System.out.println("Sum of three numbers is :"+x);

	}

}
