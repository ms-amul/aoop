package AbstractDesignPattern;
//Step 1: Create and interface for Shapes
public interface Shape {
	void draw();
}
