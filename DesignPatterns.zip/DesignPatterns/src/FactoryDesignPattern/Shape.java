package FactoryDesignPattern;

public interface Shape {
	void draw();
}
