package AdapterDesignPattern;

public interface Builder {
	 public void build(String type, String location);
}
