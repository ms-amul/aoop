package BridgeDesignPattern;

public interface FeedingAPI {
	 public void feed(int timesADay, int amount, String typeOfFood);
}
