/**
 * 
 */
/**
 * @author manoj
 *
 */
module DesignPatterns {
}