package SingletonEarlyinitialization;

public class Singleton {
	private static Singleton obj = new Singleton();
	public static Singleton getinstance()
	{
		return obj;
	}
	
	public void show()
	{
		System.out.println("Hi there This is Early initialization singleton class !!!!");
	}
}
