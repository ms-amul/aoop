package SingletonEarlyinitialization;

public class SingletonDemo extends Singleton{

	public static void main(String[] args) {
		Singleton s = Singleton.getinstance();
		
		s.show();
		

	}

}
