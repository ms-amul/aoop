package SingletonDesignPattern;

public class SingletonPatternDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingleObject object = SingleObject.getInstance();

	      //show the message
	      object.showMessage();
	}

}
