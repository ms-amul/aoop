package FacadeDesignPattern;

public class Bear implements Animal{
	 @Override
	    public void feed() {
	        System.out.println("The bear is being fed!");
	    } 
}
