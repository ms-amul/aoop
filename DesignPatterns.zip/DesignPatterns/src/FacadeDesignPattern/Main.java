package FacadeDesignPattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ZooKeeper zookeeper = new ZooKeeper();
	        
	        zookeeper.feedLion();
	        zookeeper.feedWolf();
	        zookeeper.feedBear();  
	}

}
