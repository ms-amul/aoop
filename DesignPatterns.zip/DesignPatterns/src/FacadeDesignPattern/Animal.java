package FacadeDesignPattern;

public interface Animal {
	void feed();
}
