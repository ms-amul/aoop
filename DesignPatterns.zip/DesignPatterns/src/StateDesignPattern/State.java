package StateDesignPattern;

public interface State {
	public void doAction(Context context);
}
