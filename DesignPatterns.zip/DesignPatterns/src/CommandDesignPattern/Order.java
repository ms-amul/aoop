package CommandDesignPattern;

public interface Order 
{
	void execute();
}
