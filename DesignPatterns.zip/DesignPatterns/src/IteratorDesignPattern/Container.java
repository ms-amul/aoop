package IteratorDesignPattern;

public interface Container {
	public Iterator getIterator();
}
